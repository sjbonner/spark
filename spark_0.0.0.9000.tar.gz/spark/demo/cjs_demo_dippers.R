## Load RMark
library(RMark)                          

## Retrieve dipper data from RMark
data(dipper)

## Run spark
dipper.trunc <- spark(dipper,informat="mark",outformat="mark",k=6,ragged=TRUE)

## Process data
dipper.process1 <- process.data(dipper.trunc,
                                model="CJS",
                                #begin.time=rep(1:6,2),
                                        #time.intervals=c(1,.5,1,.75,.25,1),
                                #groups=c("release","sex"))
                                begin.time=1:6,
                                groups=c("release"))

dipper.ddl1 <- make.design.data(dipper.process1)

## Run MARK
timeplussex=list(formula=~time+sex)

system.time(dipper.model1 <- mark(dipper.process1,dipper.ddl1,
                                  model.parameters=list(Phi=timeplussex,
                                      p=timeplussex)))


dipper.model1$results$real

## Original data
dipper.process2 <- process.data(dipper,
                                model="CJS",
                                groups="sex")

dipper.ddl2 <- make.design.data(dipper.process2)
                               
system.time(dipper.model2 <- mark(dipper.process2,dipper.ddl2))

dipper.model2$results$real

## Compare


